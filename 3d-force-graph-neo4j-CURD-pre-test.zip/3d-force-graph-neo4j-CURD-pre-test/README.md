# 3d-Force-Graph-Neo4j-CURD

![preview](https://github.com/HimanLGe/3d-force-graph-neo4j-CURD/blob/master/img/preview.jpg?raw=true)

## Brief

​	3d view of neo4j data,using based on 3d-force-graph & neo4j ,I want to build a Scalability system that is easy to extend any features,so it might be a little complicated

## Usage(Windows)

1. Download zip file in release,extract

2. Install node-v18.15.0-x64.msi,then open install.bat,then open start.bat

3. Enjoy my friend~

## File Description

1. testWith3dGraph.html

> ​	Integrate other files

2. basic.js

> ​	Manage 3d-force-graph preference

3. Neo4jConnector.js

> ​	Provide basic neo4j cypher command

4. eventManager.js

> ​	Manage event, including  3d-force-graph event

5. GUI.js

> Current gui plugin is dat.gui

6. GUIController.js

> Abstract layer,isolate my project & other gui plugin

7.neo4jWith3DGraph.js

> Integrate Neo4jConnector & basic.js





## Notes

This is a project in start-up phase



If you also interest in neo4j ,Data science, Welcome to discuss at:

> Telegram https://t.me/+IyqE6UoFisM5ZTg1
>
> QQ:762039266

I'm lonely. Who will chat with me.😥
