export default class history { 
    constructor() { 
        // this.historyClick = [];//also link click
        // this.arrowLeftCount = 0;//also link click
        // let _this = this;
        // window.GraphApp.eventManager.registerEvent("ArrowLeftUp", () => {
        //     _this.arrowLeftCount += 1;
        //     _this.historyClickPointer = _this.historyClick.length-_this.arrowLeftCount
        // });
        // document.addEventListener("keyup", function (event) {
            
        //     if (event.code == "ArrowLeftUp") window.GraphApp.eventManager.dispatchArrowLeftUp();
            
            
        // });
    }
}